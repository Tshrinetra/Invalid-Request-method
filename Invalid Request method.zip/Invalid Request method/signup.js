const express = require("express");
const app = express();
const fs = require("fs");
app.use(express.static(__dirname + "/public"));
app.use(express.urlencoded({ extended: true }));
app.get("/signup", (req, res) => {
	res.sendFile(__dirname + "/home.html");
});
app.post("/signup", (req, res) => {
	let arr = fs.readFileSync("users.txt", "utf-8");
	arr = JSON.parse(arr);
	arr.push(req.body);
	fs.writeFileSync("users.txt", JSON.stringify(arr));
	res.redirect("/invalid");
});
app.get("/invalid",(req,res)=>{
      let arr = fs.readFileSync("users.txt", "utf-8");
	arr = JSON.parse(arr);
      let len = arr.length;
      len = JSON.stringify(len);
      res.send("Invalid request method - " + len);
})
app.listen(3000, (err) => {
	if (err) console.log(err);
	console.log("Server Started");
});
